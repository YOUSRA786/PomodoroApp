package utils;

import java.io.*;
import java.util.*;

public class QuoteProvider {

    private static List<String> quotes = new ArrayList<>();

    static {
        try (BufferedReader reader = new BufferedReader(new FileReader("assets/quotes.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                quotes.add(line);
            }
        } catch (IOException e) {
            System.out.println("Could not load quotes: " + e.getMessage());
        }
    }

    public static String getRandomQuote() {
        if (quotes.isEmpty()) return "Keep going, you got this!";
        Random random = new Random();
        return quotes.get(random.nextInt(quotes.size()));
    }
}
