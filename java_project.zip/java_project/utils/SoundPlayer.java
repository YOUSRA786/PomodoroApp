package utils;

import javax.sound.sampled.*;
import java.io.IOException;
import java.net.URL;

public class SoundPlayer {

    public static void playSound(String soundFilePath) {
        new Thread(() -> {
            try {
                // Load sound from classpath
                URL soundURL = SoundPlayer.class.getClassLoader().getResource(soundFilePath);
                if (soundURL != null) {
                    AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundURL);
                    Clip clip = AudioSystem.getClip();
                    clip.open(audioStream);
                    clip.start();

                    clip.addLineListener(event -> {
                        if (event.getType() == LineEvent.Type.STOP) {
                            clip.close();
                        }
                    });
                } else {
                    System.out.println("Sound file not found: " + soundFilePath);
                }
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
